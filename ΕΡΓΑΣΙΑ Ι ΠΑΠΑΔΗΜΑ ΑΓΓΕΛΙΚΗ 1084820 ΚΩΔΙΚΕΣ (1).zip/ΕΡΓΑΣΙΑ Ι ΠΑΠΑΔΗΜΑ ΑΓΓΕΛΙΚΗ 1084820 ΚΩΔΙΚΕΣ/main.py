import numpy as np
from sklearn.datasets import make_classification
from sklearn. linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

X, y=make_classification(n_samples=100000, n_features=200, n_informative=10,
n_redundant=10, class_sep=1.2, flip_y=0.08, random_state=42)

X_train, X_val , y_train, y_val = train_test_split(X, y, test_size=0.2, stratify=y,
random_state=42)

scaler =StandardScaler()
X_train= scaler . fit_transform(X_train)
X_val = scaler .transform(X_val)

rng=np.random.default_rng(0)
results = []

for i in range(32):
 C=10 ** rng.uniform(-5, -1)
 clf = LogisticRegression(
 C=C, penalty="l1", solver="saga",
 max_iter=3000, n_jobs=1
 )
 clf . fit(X_train, y_train)
 acc = accuracy_score(y_val , clf .predict(X_val))
 print(f"{i :02d}: C={C:.3e}, acc={acc:.4f}")
 results .append((C, acc))

 best_C, best_acc =max(results , key=lambda t: t[1])
 print(f"Best: C={best_C:.3e}, acc={best_acc:.4f}")